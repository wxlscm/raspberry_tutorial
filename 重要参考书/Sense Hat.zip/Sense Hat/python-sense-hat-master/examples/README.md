# Sense HAT examples

- [Colour cycle](colour_cycle.py)
- [Compass](compass.py)
- [PyGame Joystick](pygame_joystick.py)
- [Rainbow](rainbow.py)
- [Rotation](rotation.py)
- [Space Invader](space_invader.py)
- [Text scroll](text_scroll.py)
