#!/usr/bin/python
from sense_hat import SenseHat

sense = SenseHat()
sense.clear()
sense.load_image("space_invader.png")
