# Socket Programming in Python (Guide)

This is the source code for [Socket Programming in Python (Guide)](https://realpython.com/python-sockets/).

## Requirements

- [Python](https://www.python.org/) 3.6 or later.

## License

The MIT License. See the file LICENSE in this repository's base directory.
