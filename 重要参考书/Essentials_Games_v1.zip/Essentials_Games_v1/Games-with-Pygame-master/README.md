#### The code + assets for 
# Make Games with Python
##### A magazine series-turned-book I wrote for Raspberry Pi's 'The MagPi' magazine

This repo contains all of the code, images, and sounds you'll need to follow the chapters and tutorials of my book, 'Make Games with Python', which you can grab for free (no strings attached, it's CC :D) [here](https://www.raspberrypi.org/magpi/issues/essentials-games-vol1/) but buying it for iOS/Android helps support the Raspberry Pi Foundation's ongoing mission to democratise computing.

![Cover image](http://sean.mtracey.org/assets/images/external/make-games-with-pygame-cover-medium.jpg)