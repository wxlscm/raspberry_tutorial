import time

x = 0
while True:
    print(x)
    time.sleep(1)
    x += 1
